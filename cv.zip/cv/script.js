// Form Submission Success Handling
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    
    if (form) {
        form.addEventListener('submit', (event) => {
            // You can add additional client-side validations here
            const requiredFields = ['name', 'dob', 'address', 'role', 'experience', 'mobile', 'resume'];
            let isValid = true;

            requiredFields.forEach((field) => {
                const input = document.querySelector(`[name="${field}"]`);
                if (input && input.value.trim() === '') {
                    alert(`${field.charAt(0).toUpperCase() + field.slice(1)} is required.`);
                    isValid = false;
                }
            });

            if (!isValid) {
                event.preventDefault();
            }
        });
    }
});
