
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="bg-white p-8 rounded-lg shadow-lg text-center space-y-6 w-96">
        <h1 class="text-3xl font-bold text-gray-700">Welcome to the Application Portal</h1>

        <p class="text-gray-600">Select an option below to proceed:</p>

        <!-- Admin Login Link -->
        <div>
            <a href="admin/login.php" 
                class="block bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring focus:ring-blue-300">
                Admin Login
            </a>
        </div>

        <!-- User Form Link -->
        <div>
            <a href="user/index.php" 
                class="block bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 focus:outline-none focus:ring focus:ring-green-300">
                Go to Application Form
            </a>
        </div>

    </div>

</body>
</html>
