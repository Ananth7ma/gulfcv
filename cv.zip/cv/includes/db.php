<?php
// Database connection details
$host = 'sql213.infinityfree.com';
$dbname = 'cv_management';
$username = 'if0_37992772'; // Change as per your database username
$password = '4idIX4kn22tF0M'; // Change as per your database password

// Create a new connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
