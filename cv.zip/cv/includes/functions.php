<?php
require_once 'db.php'; // Ensure the database connection is included

/**
 * Fetch all applications with optional filters.
 *
 * @param string $status Filter by status ('inbox', 'outbox', etc.)
 * @param string|null $role Filter by role
 * @param int|null $experience Filter by experience
 * @return array List of applications
 */
function getApplications($status = 'inbox', $role = null, $experience = null)
{
    global $conn;

    $query = "SELECT * FROM applications WHERE status = ?";
    $params = [$status];
    $types = "s";

    if ($role) {
        $query .= " AND role = ?";
        $params[] = $role;
        $types .= "s";
    }

    if ($experience !== null) {
        $query .= " AND experience = ?";
        $params[] = $experience;
        $types .= "i";
    }

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $applications = [];
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row;
    }

    return $applications;
}

/**
 * Update the status of an application.
 *
 * @param int $id Application ID
 * @param string $status New status ('inbox', 'outbox', etc.)
 * @return bool Success or failure
 */
function updateApplicationStatus($id, $status)
{
    global $conn;

    $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    return $stmt->execute();
}

/**
 * Delete an application.
 *
 * @param int $id Application ID
 * @return bool Success or failure
 */
function deleteApplication($id)
{
    global $conn;

    // Fetch the resume path for deletion
    $stmt = $conn->prepare("SELECT resume_path FROM applications WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $application = $result->fetch_assoc();

    if ($application) {
        $resumePath = $application['resume_path'];
        if (file_exists($resumePath)) {
            unlink($resumePath); // Delete the file from the server
        }
    }

    // Delete the application from the database
    $stmt = $conn->prepare("DELETE FROM applications WHERE id = ?");
    $stmt->bind_param("i", $id);

    return $stmt->execute();
}

/**
 * Reupload a resume for a specific application.
 *
 * @param int $id Application ID
 * @param string $resumePath Path to the new resume
 * @return bool Success or failure
 */
function reuploadResume($id, $resumePath)
{
    global $conn;

    $stmt = $conn->prepare("UPDATE applications SET resume_path = ? WHERE id = ?");
    $stmt->bind_param("si", $resumePath, $id);

    return $stmt->execute();
}
?>
