// Function to handle all AJAX-based success actions and reload the page once
let pageReloadRequired = false; // Flag to track if a reload is required

// Function to show the success popup message
function showSuccessPopup(message) {
    const successPopup = document.getElementById('successPopup');
    const successMessage = document.getElementById('successMessage');
    successMessage.innerText = message;
    successPopup.classList.remove('hidden');

    // Mark page reload as needed
    pageReloadRequired = true;

    // Hide the success popup after 2 seconds
    setTimeout(() => {
        successPopup.classList.add('hidden');
        if (pageReloadRequired) {
            location.reload(); // Reload the page once after 2 seconds
        }
    }, 2000);
}

// Move Application
function moveApplication(applicationId, targetStatus) {
    fetch('moveApplication.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ applicationId, targetStatus })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessPopup('Application moved successfully!');
        } else {
            alert(`Error: ${data.message}`);
        }
    })
    .catch(error => console.error('Error:', error));
}

// Open Reupload Popup
function openReuploadPopup(applicationId) {
    document.getElementById('applicationId').value = applicationId;
    document.getElementById('reuploadPopup').style.display = 'flex';
}

// Close Reupload Popup
function closeReuploadPopup() {
    document.getElementById('reuploadPopup').style.display = 'none';
}

// Handle the form submission via AJAX for reupload
function handleReupload(event) {
    event.preventDefault(); // Prevent normal form submission

    var formData = new FormData(document.getElementById('reuploadForm'));

    // Send the form data via AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'reupload.php', true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            // On success, show success popup with resume reupload success message
            document.getElementById('reuploadPopup').style.display = 'none';
            showSuccessPopup('Resume reuploaded successfully!');
        } else {
            alert('Error: ' + xhr.responseText);
        }
    };
    xhr.send(formData);
}

// Open Edit Popup (without redirecting to the PHP page)
function openEditPopup(applicationId, name, role, experience) {
    // Set initial values in the form fields
    document.getElementById('editApplicationId').value = applicationId;
    document.getElementById('editName').value = name;
    document.getElementById('editRole').value = role;
    document.getElementById('editExperience').value = experience;
    
    // Show the pop-up
    document.getElementById('editPopup').classList.remove('hidden');
}

// Close Edit Popup
function closeEditPopup() {
    document.getElementById('editPopup').classList.add('hidden');
}

// Submit the form and update application details via AJAX
function updateApplication(event) {
    event.preventDefault(); // Prevent normal form submission

    const applicationId = document.getElementById('editApplicationId').value;
    const name = document.getElementById('editName').value;
    const role = document.getElementById('editRole').value;
    const experience = document.getElementById('editExperience').value;

    // Send the data via AJAX to editApplication.php
    fetch('editApplication.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            applicationId: applicationId,
            name: name,
            role: role,
            experience: experience
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            showSuccessPopup('Application updated successfully!');
            
            // Close the popup
            closeEditPopup();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('There was an error while processing your request.');
    });
}

// Delete Application
function deleteApplication(applicationId) {
    if (confirm('Are you sure you want to delete this application?')) {
        fetch('deleteApplication.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ applicationId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccessPopup('Application deleted successfully!');
            } else {
                alert(`Error: ${data.message}`);
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

// Carousel functionality
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const carousel = document.getElementById('carousel');
const totalSlides = carousel.querySelectorAll('img').length;

let index = 0;

function moveToSlide() {
    const slideWidth = carousel.querySelector('img').clientWidth;
    carousel.style.transform = `translateX(-${index * slideWidth}px)`;
}

prevBtn.addEventListener('click', () => {
    index = (index === 0) ? totalSlides - 1 : index - 1;
    moveToSlide();
});

nextBtn.addEventListener('click', () => {
    index = (index === totalSlides - 1) ? 0 : index + 1;
    moveToSlide();
});

// Optional: Autoplay the slider
setInterval(() => {
    index = (index === totalSlides - 1) ? 0 : index + 1;
    moveToSlide();
}, 3000); // Slide every 3 seconds
