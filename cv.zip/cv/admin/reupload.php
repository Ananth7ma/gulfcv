<?php
require '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['resume']) && isset($_POST['application_id'])) {
    $applicationId = $_POST['application_id'];
    $resume = $_FILES['resume'];

    // Absolute path to the upload directory
    $uploadDir = __DIR__ . '/../uploads/';

    // Ensure the upload directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Handle file upload
    $resumeFilename = basename($resume['name']);
    $resumePath = $uploadDir . $resumeFilename;
    
    if (move_uploaded_file($resume['tmp_name'], $resumePath)) {
        // Update the resume path in the database
        $dbResumePath = '../uploads/' . $resumeFilename;

        $stmt = $conn->prepare("UPDATE applications SET resume_path = ? WHERE id = ?");
        $stmt->bind_param("si", $dbResumePath, $applicationId);
        if ($stmt->execute()) {
            // Respond with a success message
            echo "Resume reuploaded successfully.";
        } else {
            echo "Error updating the resume in the database.";
        }
    } else {
        echo "Error: Failed to upload the resume.";
    }
} else {
    echo "Invalid request.";
}
?>
