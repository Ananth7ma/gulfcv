<?php
require '../includes/db.php';

$response = ['success' => false];  // Default response

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the raw POST data
    $inputData = json_decode(file_get_contents('php://input'), true);
    
    // Extract values
    $applicationId = $inputData['applicationId'];
    $name = $inputData['name'];
    $role = $inputData['role'];
    $experience = $inputData['experience'];

    // Prepare the SQL statement to update the application
    $stmt = $conn->prepare("UPDATE applications SET name = ?, role = ?, experience = ? WHERE id = ?");
    $stmt->bind_param("ssii", $name, $role, $experience, $applicationId);

    if ($stmt->execute()) {
        $response['success'] = true;
    } else {
        $response['message'] = 'Database update failed';
    }

    echo json_encode($response); // Send back the response as JSON
}
?>
