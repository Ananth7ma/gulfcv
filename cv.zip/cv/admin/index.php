<?php
session_start();
require '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = $conn->prepare("SELECT id, username, role FROM users WHERE username = ? AND password = SHA2(?, 256)");
    $query->bind_param("ss", $username, $password);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header('Location: dashboard.php'); // Redirect to the home page
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-white p-6 rounded shadow-md w-96">
        <h2 class="text-2xl font-semibold mb-6">Login</h2>
        <?php if (isset($error)): ?>
            <p class="text-red-500"><?= $error ?></p>
        <?php endif; ?>
        <form method="POST" action="index.php">
            <div class="mb-4">
                <label for="username" class="block text-gray-600">Username</label>
                <input type="text" name="username" id="username" class="w-full border-gray-300 rounded p-2" required>
            </div>
            <div class="mb-4">
                <label for="password" class="block text-gray-600">Password</label>
                <input type="password" name="password" id="password" class="w-full border-gray-300 rounded p-2" required>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white rounded p-2 hover:bg-blue-700">Login</button>
        </form>
    </div>
</body>
</html>
