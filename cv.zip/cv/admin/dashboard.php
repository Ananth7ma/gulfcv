<?php
require '../includes/db.php';
session_start();

// Ensure the user is logged in before accessing the page
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
// Function to fetch total applications based on the status
function fetchTotalApplications($conn, $status) {
    $query = $conn->prepare("SELECT COUNT(*) as total FROM applications WHERE status = ?");
    $query->bind_param("s", $status);
    $query->execute();
    $result = $query->get_result();
    $total = $result->fetch_assoc()['total'] ?? 0;
    $query->close();
    return $total;
}

$statusInbox = 'inbox';
$statusOutbox = 'outbox';
$totalInbox = fetchTotalApplications($conn, $statusInbox);
$totalOutbox = fetchTotalApplications($conn, $statusOutbox);

$view = $_GET['view'] ?? 'home';

if ($view === 'inbox' || $view === 'outbox') {
    $roleFilter = $_GET['role'] ?? null;
    $experienceFilter = $_GET['experience'] ?? null;

    $query = "SELECT * FROM applications WHERE status = ?";
    $params = [$view];
    $types = "s";

    if ($roleFilter) {
        $query .= " AND role LIKE ?";
        $params[] = "%" . $roleFilter . "%";
        $types .= "s";
    }

    if ($experienceFilter) {
        $query .= " AND experience = ?";
        $params[] = $experienceFilter;
        $types .= "i";
    }

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Management System</title>
    <script src="script.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js" defer></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div id="successPopup" class="fixed top-4 right-4 bg-green-500 text-white p-3 rounded shadow-lg hidden">
        <span id="successMessage"></span>
    </div>

    <div class="flex">
        <div class="bg-gray-800 text-white w-64 min-h-screen p-4">
            <!-- Profile Section -->
            <div class="mb-6">
    <div class="flex items-center space-x-2">
        <div class="w-10 h-10 rounded-full bg-gray-400 flex items-center justify-center">
            <!-- Placeholder for Profile Image -->
            <i class="fas fa-user text-white"></i>
        </div>
        <div>
            <!-- Display the logged-in user's name -->
            <p class="text-sm font-medium"><?= isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Admin' ?></p>
        </div>
    </div>
</div>

            <!-- Navigation Links -->
            <nav class="space-y-4">
                <a href="dashboard.php" class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded">
                    <i class="fas fa-home"></i> <span>Home</span>
                </a>
                <a href="dashboard.php?view=inbox" class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded">
                    <i class="fas fa-inbox"></i> <span>Inbox</span>
                </a>
                <a href="dashboard.php?view=outbox" class="flex items-center space-x-2 hover:bg-gray-700 p-2 rounded">
                    <i class="fas fa-paper-plane"></i> <span>Outbox</span>
                </a>
            </nav>

            <!-- Logout Section (Optional) -->
            <?php if (isset($_SESSION['user_id'])): ?>
    <a href="logout.php" class="flex items-center space-x-2 text-red-500 hover:bg-gray-700 p-2 rounded">
        <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
    </a>
<?php endif; ?>

        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col">
            <header class="bg-white shadow p-4 flex items-center">
                <h1 class="text-xl font-semibold">CV Management System</h1>
                <img src="https://gulfengineering.in/img/logo.png" alt="CV Management System Logo" class="h-8 ml-auto">
            </header>

            <main class="flex-1 p-6">
                <!-- Dashboard and View Handling -->
                <?php if ($view === 'home') { ?>
                    <h1 class="text-2xl font-bold mb-6">Dashboard Overview</h1>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div class="bg-white shadow p-4 rounded">
                            <p class="text-gray-700 font-medium"><strong>Total Inbox Applications:</strong> <?= $totalInbox ?></p>
                        </div>
                        <div class="bg-white shadow p-4 rounded">
                            <p class="text-gray-700 font-medium"><strong>Total Outbox Applications:</strong> <?= $totalOutbox ?></p>
                        </div>
                    </div>
                <?php } elseif ($view === 'inbox' || $view === 'outbox') { ?>
                    <!-- Inbox/Outbox Content -->
                    <h1 class="text-2xl font-bold mb-4"><?= ucfirst($view) ?> Applications</h1>
                    <form method="GET" action="" class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">
                        <div>
                            <label for="role" class="block text-gray-600 font-medium mb-1">Role:</label>
                            <input type="text" name="role" id="role" value="<?= htmlspecialchars($_GET['role'] ?? '') ?>" placeholder="Search by role" class="w-full border-gray-300 rounded p-2">
                        </div>
                        <div>
                            <label for="experience" class="block text-gray-600 font-medium mb-1">Experience:</label>
                            <input type="number" name="experience" id="experience" value="<?= htmlspecialchars($_GET['experience'] ?? '') ?>" placeholder="Search by experience in years" min="0" class="w-full border-gray-300 rounded p-2">
                        </div>
                        <button type="submit" class="col-span-1 sm:col-span-2 bg-blue-600 text-white rounded p-2 hover:bg-blue-700">Apply</button>
                    </form>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white shadow rounded">
                            <thead>
                                <tr class="bg-gray-100 text-left">
                                    <th class="p-3">ID</th>
                                    <th class="p-3">Name</th>
                                    <th class="p-3">Mobile</th>
                                    <th class="p-3">Experience</th>
                                    <th class="p-3">Role</th>
                                    <th class="p-3">Address</th>
                                    <th class="p-3">Resume</th>
                                    <th class="p-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (isset($result) && $result->num_rows > 0) { ?>
                                    <?php while ($row = $result->fetch_assoc()) { ?>
                                        <tr class="border-t">
                                            <td class="p-3"><?= htmlspecialchars($row['id']) ?></td>
                                            <td class="p-3"><?= htmlspecialchars($row['name']) ?></td>
                                            <td class="p-3"><?= htmlspecialchars($row['mobile']) ?></td>
                                            <td class="p-3"><?= htmlspecialchars($row['experience']) ?> years</td>
                                            <td class="p-3"><?= htmlspecialchars($row['role']) ?></td>
                                            <td class="p-3"><?= htmlspecialchars($row['address']) ?></td>
                                            <td class="p-3">
                                                <a href="<?= htmlspecialchars($row['resume_path']) ?>" target="_blank" class="text-blue-600 hover:underline">View</a>
                                            </td>
                                            <td class="p-3 space-x-2 flex flex-wrap justify-start gap-2">
                                                <button onclick="moveApplication(<?= $row['id'] ?>, '<?= $view === 'inbox' ? 'outbox' : 'inbox' ?>')" class="bg-green-500 text-white rounded px-3 py-1 hover:bg-green-600 mt-2 mb-2">Move</button>
                                                <button onclick="openReuploadPopup(<?= $row['id'] ?>)" class="bg-yellow-500 text-white rounded px-3 py-1 hover:bg-yellow-600 mt-2 mb-2">Reupload</button>
                                                <button onclick="openEditPopup(<?= $row['id'] ?>, '<?= htmlspecialchars($row['role']) ?>', <?= $row['experience'] ?>)" class="bg-blue-500 text-white rounded px-3 py-1 hover:bg-blue-600 mt-2 mb-2">Edit</button>
                                                <button onclick="deleteApplication(<?= $row['id'] ?>)" class="bg-red-500 text-white rounded px-3 py-1 hover:bg-red-600 mt-2 mb-2">Delete</button>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="8" class="p-3 text-center text-gray-500">No applications found.</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </main>
        </div>
    </div>
    <div id="reuploadPopup" class="fixed top-0 left-0 w-full h-full bg-gray-900 bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded">
        <h2 class="text-xl font-semibold mb-4">Reupload Resume</h2>
        <form id="reuploadForm" action="reupload.php" method="POST" enctype="multipart/form-data" onsubmit="return handleReupload(event)">
            <input type="hidden" name="application_id" id="applicationId">
            <div class="mb-4">
                <label for="resume" class="block text-gray-600">Select New Resume:</label>
                <input type="file" name="resume" id="resume" class="w-full border-gray-300 rounded p-2" required>
            </div>
            <button type="submit" class="bg-blue-600 text-white rounded p-2 hover:bg-blue-700">Upload</button>
            <button type="button" onclick="closeReuploadPopup()" class="bg-gray-500 text-white rounded p-2 hover:bg-gray-600">Cancel</button>
        </form>
    </div>
</div>

<!-- Success Popup -->
<div id="successPopup" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded text-center">
        <p class="text-green-600 text-lg font-semibold">Resume reuploaded successfully!</p>
    </div>
</div>


<!-- Edit Popup -->
<div id="editPopup" class="fixed top-0 left-0 w-full h-full bg-gray-900 bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded">
        <h2 class="text-xl font-semibold mb-4">Edit Application</h2>
        <form id="editForm" onsubmit="updateApplication(event)">
            <input type="hidden" name="application_id" id="editApplicationId">
            <div class="mb-4">
                <label for="editName" class="block text-gray-600">Name:</label>
                <input type="text" name="name" id="editName" class="w-full border-gray-300 rounded p-2" required>
            </div>
            <div class="mb-4">
                <label for="editRole" class="block text-gray-600">Role:</label>
                <input type="text" name="role" id="editRole" class="w-full border-gray-300 rounded p-2" required>
            </div>
            <div class="mb-4">
                <label for="editExperience" class="block text-gray-600">Experience:</label>
                <input type="number" name="experience" id="editExperience" class="w-full border-gray-300 rounded p-2" required>
            </div>
            <button type="submit" class="bg-blue-600 text-white rounded p-2 hover:bg-blue-700">Save Changes</button>
            <button type="button" onclick="closeEditPopup()" class="bg-gray-500 text-white rounded p-2 hover:bg-gray-600">Cancel</button>
        </form>
    </div>
</div>

<!-- Success Popup Message -->
<div id="successPopup" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded shadow-lg text-center">
        <p class="text-green-600 text-lg font-semibold">Application updated successfully!</p>
    </div>
</div>
    <footer class="bg-gray-800 text-white text-center py-4">
        <p>&copy; 2024 CV Management System. All rights reserved.</p>
    </footer>
</body>
</html>
