CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    dob DATE NOT NULL,
    address TEXT NOT NULL,
    role VARCHAR(100) NOT NULL,
    experience INT NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    resume_path VARCHAR(255) NOT NULL,
    status ENUM('active', 'outbox') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
