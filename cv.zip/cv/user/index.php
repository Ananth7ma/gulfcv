<?php
require '../includes/db.php';

$successMessage = ""; // Variable to store success message
$name = $dob = $address = $role = $experience = $mobile = ""; // Initialize variables for form fields

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the form submission
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $role = $_POST['role'];
    $experience = $_POST['experience'];
    $mobile = $_POST['mobile'];
    $resume = $_FILES['resume'];

    // Absolute path to the upload directory
    $uploadDir = __DIR__ . '/../uploads/';

    // Ensure the upload directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Handle file upload
    $resumeFilename = basename($resume['name']);
    $resumePath = $uploadDir . $resumeFilename;
    if (move_uploaded_file($resume['tmp_name'], $resumePath)) {
        // Store only the relative path in the database
        $dbResumePath = '../uploads/' . $resumeFilename;

        // Insert data into the database
        $stmt = $conn->prepare("INSERT INTO applications (name, dob, address, role, experience, mobile, resume_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssiss", $name, $dob, $address, $role, $experience, $mobile, $dbResumePath);
        if ($stmt->execute()) {
            $successMessage = "Application submitted successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Error: Failed to upload the resume.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Application</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <!-- Success Popup -->
    <?php if (!empty($successMessage)): ?>
        <div id="successPopup" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <div class="bg-white p-6 rounded shadow-lg text-center">
                <p class="text-green-600 text-lg font-semibold"><?= htmlspecialchars($successMessage) ?></p>
            </div>
        </div>
        <script>
            // Hide the popup after 2 seconds
            setTimeout(() => {
                document.getElementById('successPopup').style.display = 'none';
            }, 2000);
        </script>
    <?php endif; ?>

    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 class="text-2xl font-bold mb-6 text-center text-gray-700">Submit Your Application</h1>
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label for="name" class="block text-gray-600 font-medium mb-2">Name</label>
                <input type="text" id="name" name="name" placeholder="Name" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none"
                    value="<?= htmlspecialchars($name ?? '') ?>">
            </div>
            <div>
                <label for="dob" class="block text-gray-600 font-medium mb-2">Date of Birth</label>
                <input type="date" id="dob" name="dob" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none"
                    value="<?= htmlspecialchars($dob ?? '') ?>">
            </div>
            <div>
                <label for="address" class="block text-gray-600 font-medium mb-2">Address</label>
                <textarea id="address" name="address" placeholder="Address" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none"><?= htmlspecialchars($address ?? '') ?></textarea>
            </div>
            <div>
                <label for="role" class="block text-gray-600 font-medium mb-2">Role</label>
                <input type="text" id="role" name="role" placeholder="Role" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none"
                    value="<?= htmlspecialchars($role ?? '') ?>">
            </div>
            <div>
                <label for="experience" class="block text-gray-600 font-medium mb-2">Experience (Years)</label>
                <input type="number" id="experience" name="experience" placeholder="Experience (years)" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none"
                    value="<?= htmlspecialchars($experience ?? '') ?>">
            </div>
            <div>
                <label for="mobile" class="block text-gray-600 font-medium mb-2">Mobile</label>
                <input type="text" id="mobile" name="mobile" placeholder="Mobile" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none"
                    value="<?= htmlspecialchars($mobile ?? '') ?>">
            </div>
            <div>
                <label for="resume" class="block text-gray-600 font-medium mb-2">Resume</label>
                <input type="file" id="resume" name="resume" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring focus:ring-blue-200 focus:outline-none">
            </div>
            <div>
                <button type="submit" 
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring focus:ring-blue-300">
                    Submit
                </button>
            </div>
        </form>
    </div>
</body>
</html>
